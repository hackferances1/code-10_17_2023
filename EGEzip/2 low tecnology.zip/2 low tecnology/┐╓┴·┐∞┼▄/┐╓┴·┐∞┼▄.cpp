#include <iostream>
#include <graphics.h>
#include <windows.h>
#include <time.h>
using namespace std;

PIMAGE map,dino1,dino2,obs1;

void loadimage(){
	map=newimage();
	dino1=newimage();
	dino2=newimage();
	obs1=newimage();
	getimage(map,".//images//map.png");
	getimage(dino1,".//images//dragon_1.png");
	getimage(dino2,".//images//dragon_2.png");
	getimage(obs1,".//images//item_1.png");
}

int main(){
	int jump=0,jp=0;
	int obs[100000],top=0;
	srand(time(0));
	initgraph(800,400);
	setbkcolor(BLACK);
	loadimage();
	long long time=0;
	int din=-1,bk=0;
	while (1){
		cleardevice();
		putimage(bk,350,map); 
		putimage(bk+800,350,map);
		if (bk<=-800) bk=0;
		if (din==-1) putimage(100,260-jump,dino1);
		else putimage(100,260-jump,dino2);
		
		for (int i=0;i<top;i++){
			putimage(obs[i],288,obs1);
			if (obs[i]>=50&&obs[i]<=100&&jump<=35){
				return 0;
			}
			obs[i]-=10;
		}
		
		if (keystate(VK_SPACE)&&jp==0){
			jp=1;
		}
		if (jp==1){
			jump+=5;
		}else if (jp==2){
			jump-=5;
		}
		
		if (jump>=100) jp=2;
		if (jump<=0) jp=0;
		
		if (time%10==0) din*=-1;
		if (time%100==0){
			obs[top++]=800;
		}
		
		time++;
		bk-=10;
		Sleep(5);
	}
	getch();
	closegraph();
}

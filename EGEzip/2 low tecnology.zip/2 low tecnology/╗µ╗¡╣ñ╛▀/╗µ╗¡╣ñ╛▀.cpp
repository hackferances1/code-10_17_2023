#include <graphics.h>
#include <iostream>
#include <windows.h>

using std::cout;
using std::endl;

#define c0 WHITE
#define c1 RGB(139,0,139)
#define c2 BLUE
#define c3 GREEN
#define c4 YELLOW
#define c5 EGERGB(0xFF,0xa5,0x00)
#define c6 RED
#define c7 LIGHTGRAY
#define c8 BLACK

color_t clist[9]={c0,c1,c2,c3,c4,c5,c6,c7,c8};
int cpos=0,c=0,thickness=3;

void setbk(int cp){
	setbkcolor(clist[cp]);
	c=cp;
}

void printEx(){
	std::cout<<"�����Կ�ʼ���У������Ǹû滭���ߵ��÷�:\n";
	cout<<"0/F1 WHITE\n";
	cout<<"1/F1 PURPLE\n";
	cout<<"2/F1 BLUE\n";
	cout<<"3/F1 GREEN\n";
	cout<<"4/F1 YELLOW\n";
	cout<<"5/F1 ORANGE\n";
	cout<<"6/F1 RED\n";
	cout<<"7/F1 LIGHTGRAY\n";
	cout<<"8/F1 BLACK\n\n";
	cout<<"����Ϊ������ɫ��F1, F2, ��Ϊ������ɫ";
}

int main(){
	initgraph(640,480);
	printEx(); 
	int x,y;
	while (1){
		mousepos(&x,&y);
		if (keystate(0x1)){
			setcolor(clist[cpos]);
			setfillcolor(clist[cpos]);
			fillellipse(x,y,thickness,thickness,NULL);
		}else if (keystate(0x2)){
			setcolor(c);
			setfillcolor(c);
			fillellipse(x,y,10,10,NULL);
		}else if (keystate(VK_LEFT)){
			if (thickness>0){
				thickness--;
				cout<<"�ֶ�����Ϊ"<<thickness<<endl;
				Sleep(200);
			}
		}else if (keystate(VK_RIGHT)){
            thickness++;
            cout<<"�ֶ�����Ϊ"<<thickness<<endl;
            Sleep(200);
		}
		
		if (keystate(0x31))cpos=0;
		if (keystate(0x32))cpos=1;
		if (keystate(0x33))cpos=2;
		if (keystate(0x34))cpos=3;
		if (keystate(0x35))cpos=4;
		if (keystate(0x36))cpos=5;
		if (keystate(0x37))cpos=6;
		if (keystate(0x38))cpos=7;
		if (keystate(0x39))cpos=8;
		
		if (keystate(VK_F1))setbk(0);
		if (keystate(VK_F2))setbk(1);
		if (keystate(VK_F3))setbk(2);
		if (keystate(VK_F4))setbk(3);
		if (keystate(VK_F5))setbk(4);
		if (keystate(VK_F6))setbk(5);
		if (keystate(VK_F7))setbk(6);
		if (keystate(VK_F8))setbk(7);
		if (keystate(VK_F9))setbk(8);
	}
} 

#include <graphics.h>
using namespace std;

void drawFinger(int x,int len,int bot=300){
	setlinewidth(10);
	setcolor(BLACK);
	rectangle(x-15,bot-len,x+15,bot);
}
void drawHand(int mousepos){
	int middle=mousepos/6+150;
	int index=350-(mousepos/6+170);
	drawFinger(150,100,350);
	drawFinger(180,index);
	drawFinger(210,middle);
	drawFinger(240,130);
	drawFinger(270,80);
	
	line(150-15,350,180-15,400);
	line(270+15,300,270+15,350);
	line(270+15,350,240+15,400);
}

int posY=0,posX=0;

int main(){
	initgraph(400,400);
	setcaption("����ģ����");
	setbkcolor(WHITE);
	
	while (1){
		if (keystate(VK_UP)) posY+=15;
		if (keystate(VK_DOWN)) posY-=15;
		
		if (posY<0) posY=0;
		if (posY>400) posY=400;
		
		setbkcolor(EGERGB(255,(400-posY)/2,0));
		drawHand(posY);
		Sleep(10);
		cleardevice();
	}
	getch();
	closegraph();
}

//youtube learning unit2
#define GLUT_DISABLE_ATEXIT_HACK
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

void display(){
	glClear(GL_COLOR_BUFFER_BIT);//clear
	glLoadIdentity();//reset cordinate system
	
	//draw
	
	/*POINTS
		glPointSize(10.0);//set width size to 10 pixel 
		glBegin(GL_POINTS);//start drawing
		//points:create pos(x,y) to indivate a point and draw in square
		glVertex2f(5,5);//create a vertex in 2f (5,5) (float)
		glVertex2f(-5,-5);//create a vertex in 2f (-5,-5) (float)
		
		glEnd();//finnish drawing
	*/
	
	/*TRIANGLE
		glBegin(GL_TRIANGLES);
		//triangle:create three point to connect together to form a triangle
		glVertex2f(0.0,5.0);
		glVertex2f(4.0,-3.0);
		glVertex2f(-4.0,-3.0);
		
		glEnd();
	*/
	
	//POLYGON
	glBegin(GL_POLYGON);//reminder: no "S" behind "POLYGON"
	//polygons:create using four or more points to form a shape by anti-clockwise
	glVertex2f(0.0,5.0);
	glVertex2f(-4.0,-3.0);
	glVertex2f(4.0,-3.0);
	glVertex2f(5.0,-2.0);
	
	glEnd();
	
	glFlush();
}

void reshape(int w,int h){
	//viewport: An area for drawing but the obj u draw cannot been out of that area
	glViewport(0,0,(GLsizei)w,(GLsizei)h);//area of the viewport (take viewport as the hole part of screen)
	glMatrixMode(GL_PROJECTION);//set the matrix
	glLoadIdentity();//reset cordinate system
	gluOrtho2D(-10,10,-10,10);//area in measure to
	glMatrixMode(GL_MODELVIEW);//set the matrix
	
}

void init(){
}

int main(int argc,char **argv)
{
	glutInit(&argc,argv);//init glut
	glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);//mode
	glutInitWindowPosition(200,100);//window position set
	glutInitWindowSize(500,500);//window size set
	
	glutCreateWindow("title");//create window & set title
	glutDisplayFunc(display);//upload display function
	glutReshapeFunc(reshape);//upload reshape function
	init();//function for initlizing background
	glutMainLoop();//in loop
	return 0;
}

//youtube learning unit3 
#define GLUT_DISABLE_ATEXIT_HACK
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

void display();
void reshape(int,int);
void timer(int);
void init();

int main(int argc,char **argv)
{
	glutInit(&argc,argv);//init glut
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);//SINGLE:constant DOUBLE:animation
	glutInitWindowPosition(200,100);//window position set
	glutInitWindowSize(500,500);//window size set
	glutCreateWindow("title");//create window & set title
	
	glutDisplayFunc(display);//upload display function
	glutReshapeFunc(reshape);//upload reshape function
	glutTimerFunc(0,timer,0);//delay for x mili-seconds & upload timer function
	init();//function for initlizing background
	
	glutMainLoop();//in loop
	return 0;
}

float x_position=-10.0;
int state=1; 

void display(){
	glClear(GL_COLOR_BUFFER_BIT);//clear
	glLoadIdentity();//reset cordinate system
	//POLYGON
	glBegin(GL_POLYGON);//reminder: no "S" behind "POLYGON"
	//polygons:create using four or more points to form a shape by anti-clockwise
	glVertex2f(x_position,-1.0);
	glVertex2f(x_position+2,-1.0);
	glVertex2f(x_position+2,1.0);
	glVertex2f(x_position,1.0);
	
	glEnd();
	
	glutSwapBuffers();
}

void reshape(int w,int h){
	//viewport: An area for drawing but the obj u draw cannot been out of that area
	glViewport(0,0,(GLsizei)w,(GLsizei)h);//area of the viewport (take viewport as the hole part of screen)
	glMatrixMode(GL_PROJECTION);//set the matrix
	glLoadIdentity();//reset cordinate system
	gluOrtho2D(-10,10,-10,10);//area in measure to
	glMatrixMode(GL_MODELVIEW);//set the matrix
	
}

void timer(int){
	glutPostRedisplay();//it post the urge for redisplay
	glutTimerFunc(1000.0/60.0,timer,0);//wait for frame in fps=60 
	
	if (state==1){
		x_position+=0.15;
	}else{
		x_position+=-0.15;
	}
	
	if (x_position>8||x_position<-10.0){
		state*=-1;
	}
}

void init(){
	glClearColor(0.0,0.0,0.0,1.0);
}

#define GLUT_DISABLE_ATEXIT_HACK
#define v(x) x/256.0
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

void display(){
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	glTranslatef(-5,-5,-15);
	
	glBegin(GL_QUADS);
    glColor3f(1.0,0.5,0.0);
    glVertex3f(-1.0,1.0,1.0);
    glVertex3f(-1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,1.0);
    glVertex3f(1.0,1.0,1.0);
    glVertex3f(1.0,1.0,-1.0);
    glVertex3f(1.0,-1.0,-1.0);
    glVertex3f(-1.0,-1.0,-1.0);
    glVertex3f(-1.0,1.0,-1.0);
    glVertex3f(1.0,1.0,1.0);
    glVertex3f(1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,-1.0);
    glVertex3f(1.0,1.0,-1.0);
    glVertex3f(-1.0,1.0,-1.0);
    glVertex3f(-1.0,-1.0,-1.0);
    glVertex3f(-1.0,-1.0,1.0);
    glVertex3f(-1.0,1.0,1.0);
    glVertex3f(-1.0,1.0,-1.0);
    glVertex3f(-1.0,1.0,1.0);
    glVertex3f(1.0,1.0,1.0);
    glVertex3f(1.0,1.0,-1.0);
    glVertex3f(-1.0,-1.0,-1.0);
    glVertex3f(-1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,-1.0);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0.5,0.5,0.5);
	glVertex3f(-10,-2,-10);
	glVertex3f(-10,-2,10);
	glVertex3f(10,-2,10);
	glVertex3f(10,-2,-10);
	glEnd();
	
	glFlush();
}

void reshape(int w,int h){
	glViewport(0,0,w,h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(80,16.0/9.0,2.0,50.0);
	glMatrixMode(GL_MODELVIEW);
} 

void init(){
	glClearColor(v(135),v(206),v(250),1.0);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	
	GLfloat light_position[]= {5.0, 3.0, 0.0, 1.0};
    GLfloat light_diffuse[] = { 1.0, 1.0, 1.0, 0.2 };

    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	
	glEnable(GL_LIGHT0);
} 

int main(int argc,char **argv){
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_SINGLE | GLUT_DEPTH);
	glutInitWindowPosition(0,0);
	glutInitWindowSize(16,9);
	
	glutCreateWindow("��Դ����");
	glutFullScreen();
	
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	init();
	
	glutMainLoop();
}

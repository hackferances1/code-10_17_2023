#define GLUT_DISABLE_ATEXIT_HACK
#define _USE_MATH_DEFINES
#define v(x) x/255.0
#include <iostream>
#include <cmath>
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

void display();
void reshape(int,int);
void timer(int);
//void move(int,int);
void init();

int main(int argc,char **argv)
{
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowPosition(0,0);
	glutInitWindowSize(1536,864);
	glutCreateWindow("title");
	glutFullScreen(); 
	
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutTimerFunc(0,timer,0);
	//glutPassiveMotionFunc(move);
	init();
	
	glutMainLoop();//in loop
	return 0;
}

float angle=0;

void display(){
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//clear
	glLoadIdentity();
	
	glTranslatef(0,0.0,-15.0);
	glRotatef(30,1.0,0.0,0.0);
	
	glBegin(GL_QUADS);
	glColor3f(0.5,0.5,0.5);
	glVertex3f(-10,-2,-10);
	glVertex3f(-10,-2,10);
	glVertex3f(10,-2,10);
	glVertex3f(10,-2,-10);
	glEnd();
	
	glRotatef(-angle/2,0.0,1.0,0.0);
	
	//�������� 
	glBegin(GL_QUADS);
    glColor3f(1.0,0.5,0.0);
    glVertex3f(-1.0,1.0,1.0);
    glVertex3f(-1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,1.0);
    glVertex3f(1.0,1.0,1.0);
    glVertex3f(1.0,1.0,-1.0);
    glVertex3f(1.0,-1.0,-1.0);
    glVertex3f(-1.0,-1.0,-1.0);
    glVertex3f(-1.0,1.0,-1.0);
    glVertex3f(1.0,1.0,1.0);
    glVertex3f(1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,-1.0);
    glVertex3f(1.0,1.0,-1.0);
    glVertex3f(-1.0,1.0,-1.0);
    glVertex3f(-1.0,-1.0,-1.0);
    glVertex3f(-1.0,-1.0,1.0);
    glVertex3f(-1.0,1.0,1.0);
    glVertex3f(-1.0,1.0,-1.0);
    glVertex3f(-1.0,1.0,1.0);
    glVertex3f(1.0,1.0,1.0);
    glVertex3f(1.0,1.0,-1.0);
    glVertex3f(-1.0,-1.0,-1.0);
    glVertex3f(-1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,-1.0);
	glEnd();
	
	glRotatef(angle,0.0,1.0,0.0);
	glTranslatef(5,0,0);
	glRotatef(-angle,0.0,1.0,0.0);
	
	glBegin(GL_QUADS);
    glColor3f(v(65),v(105),1.0);
    glVertex3f(-0.5,0.5,0.5);
    glVertex3f(-0.5,-0.5,0.5);
    glVertex3f(0.5,-0.5,0.5);
    glVertex3f(0.5,0.5,0.5);
    glVertex3f(0.5,0.5,-0.5);
    glVertex3f(0.5,-0.5,-0.5);
    glVertex3f(-0.5,-0.5,-0.5);
    glVertex3f(-0.5,0.5,-0.5);
    glVertex3f(0.5,0.5,0.5);
    glVertex3f(0.5,-0.5,0.5);
    glVertex3f(0.5,-0.5,-0.5);
    glVertex3f(0.5,0.5,-0.5);
    glVertex3f(-0.5,0.5,-0.5);
    glVertex3f(-0.5,-0.5,-0.5);
    glVertex3f(-0.5,-0.5,0.5);
    glVertex3f(-0.5,0.5,0.5);
    glVertex3f(-0.5,0.5,-0.5);
    glVertex3f(-0.5,0.5,0.5);
    glVertex3f(0.5,0.5,0.5);
    glVertex3f(0.5,0.5,-0.5);
    glVertex3f(-0.5,-0.5,-0.5);
    glVertex3f(-0.5,-0.5,0.5);
    glVertex3f(0.5,-0.5,0.5);
    glVertex3f(0.5,-0.5,-0.5);
	glEnd();
	
	glutSwapBuffers();
}

void reshape(int w,int h){
	glViewport(0,0,w,h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(80,16.0/9.0,2.0,50.0);
	glMatrixMode(GL_MODELVIEW);
}

void timer(int){
	glutPostRedisplay();
	glutTimerFunc(1000.0/60.0,timer,0);
	angle++;
	if (GetKeyState(0x1B)&0x8000){//��ESC�˳� 
		exit(0);
	}
}

void init(){
	glClearColor(v(135),v(206),v(250),1.0);
	glEnable(GL_DEPTH_TEST);
}

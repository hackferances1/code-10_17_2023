#define GLUT_DISABLE_ATEXIT_HACK
#define _USE_MATH_DEFINES
#include <iostream>
#include <cmath>
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

void display();
void reshape(int,int);
void timer(int);
void move(int,int);
void init();

int main(int argc,char **argv)
{
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowPosition(0,0);
	glutInitWindowSize(1536,864);
	glutCreateWindow("title");
	glutFullScreen(); 
	
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutTimerFunc(0,timer,0);
	glutPassiveMotionFunc(move);
	init();
	
	glutMainLoop();//in loop
	return 0;
}

float x=0.0,z=-8.0,y=-1.0; 
float mx,my;

void display(){
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//clear
	glLoadIdentity();
	//glRotatef(my,0.5,0.0,0.5);
	glRotatef(mx,0.0,1.0,0.0);
	glTranslatef(x,y,z);
	
	//��ƽ�� 
	glBegin(GL_QUADS);
	glColor3f(0.5,0.5,0.5);
	glVertex3f(10.0,-1.0,-10.0);
	glVertex3f(10.0,-1.0,10.0);
	glVertex3f(-10.0,-1.0,10.0);
	glVertex3f(-10,-1.0,-10.0);
	glEnd();
	
	//�������� 
	glBegin(GL_QUADS);
    glColor3f(1.0,0.5,0.0);
    glVertex3f(-1.0,1.0,1.0);
    glVertex3f(-1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,1.0);
    glVertex3f(1.0,1.0,1.0);
    glVertex3f(1.0,1.0,-1.0);
    glVertex3f(1.0,-1.0,-1.0);
    glVertex3f(-1.0,-1.0,-1.0);
    glVertex3f(-1.0,1.0,-1.0);
    glVertex3f(1.0,1.0,1.0);
    glVertex3f(1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,-1.0);
    glVertex3f(1.0,1.0,-1.0);
    glVertex3f(-1.0,1.0,-1.0);
    glVertex3f(-1.0,-1.0,-1.0);
    glVertex3f(-1.0,-1.0,1.0);
    glVertex3f(-1.0,1.0,1.0);
    glVertex3f(-1.0,1.0,-1.0);
    glVertex3f(-1.0,1.0,1.0);
    glVertex3f(1.0,1.0,1.0);
    glVertex3f(1.0,1.0,-1.0);
    glVertex3f(-1.0,-1.0,-1.0);
    glVertex3f(-1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,1.0);
    glVertex3f(1.0,-1.0,-1.0);
	glEnd();
	
	//���� 
	glLineWidth(3);
	glBegin(GL_LINES);
	glColor3f(0.0,0.0,0.0);
	glVertex3f(-1.0,1.0,1.0);
	glVertex3f(1.0,1.0,1.0);
	glVertex3f(1.0,1.0,1.0);
	glVertex3f(1.0,-1.0,1.0);
	glVertex3f(1.0,-1.0,1.0);
	glVertex3f(-1.0,-1.0,1.0);
	glVertex3f(-1.0,-1.0,1.0);
	glVertex3f(-1.0,1.0,1.0);
	glVertex3f(-1.0,1.0,-1.0);
	glVertex3f(1.0,1.0,-1.0);
	glVertex3f(1.0,1.0,-1.0);
	glVertex3f(1.0,-1.0,-1.0);
	glVertex3f(1.0,-1.0,-1.0);
	glVertex3f(-1.0,-1.0,-1.0);
	glVertex3f(-1.0,-1.0,-1.0);
	glVertex3f(-1.0,1.0,-1.0);
	glVertex3f(-1.0,1.0,1.0);
	glVertex3f(-1.0,1.0,-1.0);
	glVertex3f(1.0,1.0,1.0);
	glVertex3f(1.0,1.0,-1.0);
	glVertex3f(1.0,-1.0,1.0);
	glVertex3f(1.0,-1.0,-1.0);
	glVertex3f(-1.0,-1.0,1.0);
	glVertex3f(-1.0,-1.0,-1.0);
	glEnd();
	
	glutSwapBuffers();
}

void reshape(int w,int h){
	glViewport(0,0,w,h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(40,16.0/9.0,2.0,50.0);
	glMatrixMode(GL_MODELVIEW);
}

void timer(int){
	glutPostRedisplay();
	glutTimerFunc(1000.0/60.0,timer,0);
	float angle=mx*(M_PI/180.0);
	float dx=0.1*sin(angle);
	float dz=-0.1*cos(angle);
	
	if (GetKeyState(0x41)&0x8000){
	    x -= dz;
	    z += dx;
	} else if (GetKeyState(0x44)&0x8000){
	    x += dz;
	    z -= dx;
	} else if (GetKeyState(0x57)&0x8000){
	    x -= dx;
	    z -= dz;
	} else if (GetKeyState(0x53)&0x8000){
	    x += dx;
	    z += dz;
	} else {
		y=-1.0;
	}
	
	if (GetKeyState(0x1B)&0x8000){//��ESC�˳� 
		exit(0);
	}
}

void move(int x,int y){
	mx+=(x-glutGet(GLUT_SCREEN_WIDTH)/2)*0.1;
	my+=(y-glutGet(GLUT_SCREEN_HEIGHT)/2)*0.1;
	glutWarpPointer(glutGet(GLUT_SCREEN_WIDTH)/2,glutGet(GLUT_SCREEN_HEIGHT)/2);
}

void init(){
	glClearColor(1.0,1.0,1.0,1.0);
	glEnable(GL_DEPTH_TEST);
}

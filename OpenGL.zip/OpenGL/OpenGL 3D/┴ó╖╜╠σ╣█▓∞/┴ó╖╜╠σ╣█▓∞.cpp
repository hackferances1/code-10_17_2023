#define GLUT_DISABLE_ATEXIT_HACK
#define _USE_MATH_DEFINES
#define v(x) x/256.0
#include <iostream>
#include <cmath>
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include "myglut.h"//����ͷ�ļ� 

void display();
void reshape(int,int);
void timer(int);
void move(int,int);
void init();

int main(int argc,char **argv)
{
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowPosition(0,0);
	glutInitWindowSize(1536,864);
	glutCreateWindow("title");
	glutFullScreen(); 
	
	init();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutTimerFunc(0,timer,0);
	glutPassiveMotionFunc(move);
	
	glutMainLoop();//in loop
	return 0;
}

float mx,my;
float dis=-8.0;

void display(){
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//clear
	glLoadIdentity();
	glTranslatef(0.0,-1.0,dis);
	glRotatef(mx,0.0,1.0,0.0);
	
	//�������� 
	glBegin(GL_QUADS);
	glColor3f(1.0,0.5,0.0);
    myCube3f(1.0,0.0,1.0,-1.0,-2.0,-1.0);//myglut.h���ú��� 
	glEnd();
	
	glutSwapBuffers();
}

void reshape(int w,int h){
	glViewport(0,0,w,h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(80,16.0/9.0,2.0,50.0);
	glMatrixMode(GL_MODELVIEW);
}

void timer(int){
	glutPostRedisplay();
	glutTimerFunc(1000.0/60.0,timer,0);
	//���������WINDOWS�� 
	if (GetKeyState(0x57)&0x8000){
		if (dis<-5.0) dis+=0.1;
	}else if (GetKeyState(0x53)&0x8000){
		if (dis>-20.0) dis-=0.1;
	}
	if (GetKeyState(0x1B)&0x8000){//��ESC�˳� 
		exit(0);
	}
}

void move(int x,int y){
	mx+=(x-glutGet(GLUT_SCREEN_WIDTH)/2)*0.1;
	my+=(y-glutGet(GLUT_SCREEN_HEIGHT)/2)*0.1;
	glutWarpPointer(glutGet(GLUT_SCREEN_WIDTH)/2,glutGet(GLUT_SCREEN_HEIGHT)/2);
}

void init(){
	glClearColor(v(135),v(206),v(250),1.0);
	glEnable(GL_DEPTH_TEST);
	
	glEnable(GL_LIGHTING);
	
	GLfloat light_position[]= {0.0, 0.0, 5.0, 1.0};
    GLfloat light_diffuse[] = { 1.0, 0.5, 0.0, 1.0 };

    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	
	glEnable(GL_LIGHT0);
}
